

v0.1 måler batterispenning og viser på lcd